package com.restful.microservices.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DropboxCloudPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(DropboxCloudPocApplication.class, args);
	}
}
