package com.restful.microservices.example.proxy.vo;

public class ExchangeValue {

}
